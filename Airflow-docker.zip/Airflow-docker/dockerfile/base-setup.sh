echo “Installing Setup \n\n”
apt update -y
apt upgrade -y
apt update -y --force-yes
apt install -y python3
apt install -y python3-pip
pip3 install apache-airflow
echo “Init airflow db\n\n”
airflow db init
echo “creating user db\n\n”
airflow users create --role Admin --username admin --email admin --firstname admin --lastname admin --password admin