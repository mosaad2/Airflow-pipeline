#!/bin/sh
pip3 install pandas
apt install python
apt install -y python3-dev build-essential default-libmysqlclient-dev
pip3 install mysqlclient
pip3 install sqlalchemy
pip3 install sqlalchemy_utils
apt install python3-requests