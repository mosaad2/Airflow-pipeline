#! /bin/sh
airflow webserver -D 
airflow scheduler 